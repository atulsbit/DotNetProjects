﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Interop;

namespace TCMSCOMAddIn
{
    [ComVisible(true)]
    [ClassInterface(ClassInterfaceType.None)]
    [Guid("0BE0480C-A6B1-43C4-BD43-191445D9A48E")]
    public class TCMSCom : ITCMSCom
    {
        public string OpenConfirmationWizard()
        {
            TCMSWizard ui = new TCMSWizard();
            ui.ShowDialog();

            //UserControl1 ui = new UserControl1();
            //ui.ShowDialog();
            return string.Empty;
        }

        // System.Diagnostics.Debugger.Break();

        //UserControl1 ui = new UserControl1();
        //ui.ShowDialog();

            //Task.Factory.StartNew(() => 
            //    {
            //        MainWindow ui = new MainWindow();
            //        ui.ShowDialog();
            //    }
            //);

            //TCMSWizard ui = new TCMSWizard();

            //WindowInteropHelper helper = new WindowInteropHelper(ui);
            //helper.Owner = Process.GetCurrentProcess().MainWindowHandle;
            //ui.ShowDialog();

            //IntPtr wnd = new IntPtr(0);
            //object window = Globals.ThisAddIn.Application.ActiveWindow();
            //if (window != null)
            //{
            //    IOleWindow oleWindow = window as IOleWindow;
            //    if (oleWindow != null)
            //    {
            //        oleWindow.GetWindow(out wnd);
            //    }
            //}

            //if (wnd != IntPtr.Zero)
            //{
            //    WindowInteropHelper helper = new WindowInteropHelper(ui);
            //    helper.Owner = wnd;
            //    ui.ShowInTaskbar = false;
            //}


            //ui.ShowDialog();
            //return string.Empty;
    }
}
