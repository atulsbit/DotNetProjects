﻿using System.Runtime.InteropServices;

namespace TCMSCOMAddIn
{
    [ComVisible(true)]
    [InterfaceType(ComInterfaceType.InterfaceIsDual)]
    [Guid("19E9A25A-D7AE-42FF-B0BD-C1CAF4E67811")]
    public interface ITCMSCom
    {
        string OpenConfirmationWizard();
    }
}