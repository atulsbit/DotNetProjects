# mean_stack_tutorial_real_time_todo_app
Todo App using Angular4, Expressjs, Socket.io and MongoDB

Tutorial : https://medium.com/@vipinswarnkar1989/socket-io-in-mean-angular4-todo-app-29af9683957f
